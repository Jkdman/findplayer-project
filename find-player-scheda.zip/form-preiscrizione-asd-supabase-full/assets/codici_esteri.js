{
  "Francia": "Z110",
  "Germania": "Z112",
  "Spagna": "Z135",
  "Regno Unito": "Z114",
  "Svizzera": "Z133",
  "Austria": "Z102",
  "Stati Uniti": "Z404"
  // ... altri paesi
}
