<?php
/**
 * Placeholder for FPDF library.
 * NOTE: This plugin currently uses a lightweight internal PDF generator.
 * If you prefer the full FPDF features (fonts, images, etc.),
 * replace this file with the official fpdf.php (http://www.fpdf.org/).
 */
