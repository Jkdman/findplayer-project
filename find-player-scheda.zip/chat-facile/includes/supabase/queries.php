<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ======================================================
 * CHAT FACILE — SUPABASE QUERIES (DISABILITATE)
 * ======================================================
 *
 * Questo file è volutamente vuoto.
 * Le query Supabase verranno riattivate
 * quando abiliteremo realtime / notifiche.
 */