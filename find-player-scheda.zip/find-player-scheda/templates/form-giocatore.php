<form id="fp-player-form-form" class="fp-wrapper">

<div class="fp-section">
<h3>Dati personali</h3>
<div class="fp-row">
<label>Nome <input type="text" name="nome" required></label>
<label>Cognome <input type="text" name="cognome" required></label>
</div>

<div class="fp-row">
<label>Nickname <input type="text" name="nickname" required></label>
</div>
</div>

<div class="fp-section">
<h3>Discipline sportive</h3>
<div id="discipline-wrapper"></div>
<button type="button" id="aggiungi-disciplina" class="fp-btn-secondary">+ Aggiungi disciplina</button>
</div>
<button type="button" id="aggiungi-tutti" class="fp-btn-secondary">
⚡ Inserisci tutti gli sport
</button>
</div>

<div class="fp-section">
<button type="submit" class="fp-btn">Crea la scheda giocatore</button>
</div>

</form>